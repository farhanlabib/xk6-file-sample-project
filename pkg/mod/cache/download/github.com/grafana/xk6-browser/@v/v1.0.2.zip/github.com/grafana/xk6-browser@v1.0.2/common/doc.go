// Package common contains the implementation of API elements that do not
// depend on the browser type.
package common
