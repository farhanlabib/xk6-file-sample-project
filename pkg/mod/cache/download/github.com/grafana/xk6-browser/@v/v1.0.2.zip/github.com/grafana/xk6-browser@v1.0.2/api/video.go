package api

// Video is the interface of a recorded video.
type Video interface {
	Path() string
}
