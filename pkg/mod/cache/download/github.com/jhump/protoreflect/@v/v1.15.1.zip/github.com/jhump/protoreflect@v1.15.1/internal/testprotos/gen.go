package testprotos

//go:generate ./make_protos.sh
