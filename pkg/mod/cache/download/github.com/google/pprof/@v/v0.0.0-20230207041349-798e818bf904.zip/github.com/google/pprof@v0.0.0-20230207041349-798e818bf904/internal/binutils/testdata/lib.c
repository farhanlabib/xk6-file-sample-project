int foo() {
  return 1;
}

int bar() {
  return 2;
}
