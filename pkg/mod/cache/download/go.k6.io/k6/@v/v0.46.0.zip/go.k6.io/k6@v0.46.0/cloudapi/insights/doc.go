// Package insights contains the domain data structures and client logic
// for the k6 cloud Insights API.
package insights
