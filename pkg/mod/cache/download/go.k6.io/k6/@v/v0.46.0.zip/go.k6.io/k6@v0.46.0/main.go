package main

import (
	"go.k6.io/k6/cmd"
)

func main() {
	cmd.Execute()
}
