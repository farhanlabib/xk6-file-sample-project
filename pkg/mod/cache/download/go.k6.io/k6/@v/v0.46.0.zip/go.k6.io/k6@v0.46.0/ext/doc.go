// Package ext contains the extension registry and all generic functionality for
// k6 extensions.
package ext
