import { f2 } from "./imported.js"

export default function() {
  f2();
}
