// Package http implements the k6/http js module for k6.
// That module is used to make http requests.
package http
